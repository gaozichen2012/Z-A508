#ifndef __DRVKEYBOARD_H
#define __DRVKEYBOARD_H

extern u8 drv_keypad_scan(void);
#endif